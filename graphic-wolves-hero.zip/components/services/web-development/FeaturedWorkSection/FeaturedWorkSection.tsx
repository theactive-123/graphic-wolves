"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Link from "next/link";

import { caseStudies } from "@/components/case-studies/data";
import styles from "./FeaturedWorkSection.module.css";

gsap.registerPlugin(ScrollTrigger);

const projects = caseStudies
  .filter((study) => study.category === "Web Development")
  .map((study) => ({
    slug: study.slug,
    name: study.title,
    category: study.category,
    image:
      study.heroMedia.type === "image"
        ? study.heroMedia.src
        : study.heroMedia.poster,
    alt: study.heroMedia.alt,
  }));

const projectColumns = [
  projects.filter((_, index) => index % 3 === 0),
  projects.filter((_, index) => index % 3 === 1),
  projects.filter((_, index) => index % 3 === 2),
];

export default function FeaturedWorkSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const swirlRevealRef = useRef<SVGRectElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const context = gsap.context(() => {
      const swirlReveal = swirlRevealRef.current;

      if (swirlReveal) {
        gsap.fromTo(
          swirlReveal,
          { attr: { width: 0 } },
          {
            attr: { width: 224 },
            ease: "none",
            scrollTrigger: {
              trigger: section,
              start: "top 78%",
              end: "top 28%",
              scrub: 1,
              invalidateOnRefresh: true,
            },
          },
        );
      }

      if (headingRef.current) {
        gsap.fromTo(
          headingRef.current,
          { y: 48, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            ease: "power3.out",
            scrollTrigger: {
              trigger: headingRef.current,
              start: "top 88%",
              end: "top 55%",
              scrub: 0.8,
            },
          },
        );
      }

      gsap.fromTo(
        section.querySelectorAll("[data-work-card]"),
        { y: 48, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.08,
          ease: "power3.out",
          scrollTrigger: {
            trigger: section,
            start: "top 74%",
            end: "top 30%",
            scrub: 0.8,
          },
        },
      );
    }, section);

    return () => context.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={styles.section}
      aria-labelledby="web-featured-work-title"
    >
      <img
        className={styles.orangeIcon}
        src="/images/services/web-development/featured-work/orange-icon.svg"
        alt=""
        aria-hidden="true"
      />

      <div className={styles.inner}>
        <h2
          ref={headingRef}
          id="web-featured-work-title"
          className={styles.heading}
        >
          <span>Featured</span>
          <span className={styles.work}>WORK
            <svg
          className={styles.swirl}
          viewBox="0 -1 222 11"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <defs>
            <clipPath id="web-featured-swirl-clip">
              <rect
                ref={swirlRevealRef}
                x="-1"
                y="-1"
                width="0"
                height="11"
              />
            </clipPath>
          </defs>
          <path
            fill="#ffffff"
            clipPath="url(#web-featured-swirl-clip)"
            d="M95.1846 -0.495605C95.876 -0.469976 96.5038 -0.14305 96.6426 0.48291C96.7993 1.18984 96.2341 1.74386 95.5068 1.97412C94.2262 2.37944 92.8989 2.65985 91.6279 2.94873C88.4288 3.67395 85.25 4.29395 82.1094 5.1333H82.1084C81.3262 5.34066 80.5477 5.53413 79.8262 5.79932C80.9015 5.96438 82.0387 5.9821 83.1729 6.02588H83.1719C89.2787 6.24758 95.4195 5.96852 101.553 5.71924L105.275 5.56396C123.883 4.76639 142.419 3.60541 161.049 2.8042C166.466 2.5715 171.914 2.25805 177.359 2.27393H177.36C182.599 2.28722 187.832 2.58778 193.043 2.95361L196.613 3.22217C204.945 3.87696 213.282 4.66513 221.59 4.20361C221.859 4.18825 222.106 4.28551 222.277 4.47607C222.438 4.65463 222.501 4.87939 222.501 5.07959C222.5 5.47335 222.23 5.96301 221.647 5.99658H221.646C219.54 6.11121 217.433 6.14376 215.327 6.11182C210.272 6.03474 205.233 5.69262 200.206 5.31201C195.175 4.93108 190.162 4.51186 185.138 4.27783C174.29 3.77055 163.459 4.47096 152.584 4.98291C133.69 5.86711 114.772 7.12762 95.8457 7.72119L95.8467 7.72217C90.7228 7.89369 85.4016 8.18644 80.2285 7.62646V7.62744C79.9471 7.60154 79.168 7.56686 78.4814 7.41748C78.1382 7.34277 77.7688 7.23009 77.4727 7.04736C77.1728 6.86233 76.8711 6.5521 76.8604 6.08154V6.07861C76.8508 5.54292 77.2039 5.17705 77.4902 4.96143C77.7861 4.73863 78.1369 4.58055 78.3408 4.48682L78.3477 4.48389L78.3555 4.48096C79.4872 4.00418 80.6578 3.6251 81.8545 3.34912C84.4555 2.66775 87.1063 2.11565 89.7168 1.54248C88.9137 1.58444 88.1107 1.62842 87.3076 1.67529H87.3066C76.5626 2.29195 65.8427 3.28485 55.1367 4.42627C36.9831 6.35742 18.7239 9.05736 0.396484 9.50049L0.394531 9.49365C0.12728 9.49215 -0.106743 9.38381 -0.267578 9.19678C-0.420435 9.0189 -0.484614 8.79855 -0.484375 8.59717C-0.484039 8.39569 -0.419126 8.17582 -0.266602 7.99854C-0.125286 7.8343 0.072652 7.72923 0.300781 7.70557L0.400391 7.69971C2.29807 7.65476 4.19915 7.57858 6.09863 7.48096L7.85742 7.3833C26.0316 6.32721 44.0782 3.69003 62.2373 1.89014C73.1061 0.814807 84.0928 -0.270913 95.0459 -0.496582L95.1846 -0.495605Z"
          />
        </svg>
          </span>
          
        </h2>

        

        <div className={styles.grid}>
          {projectColumns.map((column, columnIndex) => (
            <div
              key={columnIndex}
              className={styles.column}
              data-column={columnIndex + 1}
            >
              {column.map((project) => (
                <article
                  key={project.slug}
                  className={styles.card}
                  data-work-card
                >
                  <Link
                    href={`/our-work/${project.slug}`}
                    className={styles.cardLink}
                    aria-label={`View the ${project.name} case study`}
                  >
                    <div className={styles.imageWrap}>
                      <img
                        className={styles.image}
                        src={project.image}
                        alt={project.alt}
                        loading="lazy"
                      />
                    </div>
                    <h3 className={styles.title}>
                      <span className={styles.name}>{project.name}</span>
                      <span className={styles.category}> | {project.category}</span>
                    </h3>
                    <p className={styles.caption}>View case study</p>
                  </Link>
                </article>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}