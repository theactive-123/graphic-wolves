"use client";

import {
  FormEvent,
  useLayoutEffect,
  useRef,
  useState,
} from "react";

import Link from "next/link";
import gsap from "gsap";

import styles from "./FooterSection.module.css";

/* =========================================================
   MENU
========================================================= */

const menuItems = [
  {
    label: "Home",
    href: "/",
  },
  {
    label: "Services",
    href: "/services",
  },
  {
    label: "Our Work",
    href: "/our-work",
  },
  {
    label: "Blog",
    href: "/blog",
  },
  {
    label: "Contact",
    href: "/contact",
  },
  {
    label: "Schedule a Call",
    href: "/schedule",
  },
];


const socials = [
  {
    label: "Facebook",
    href: "https://www.facebook.com/graphicwolves",
    icon: "/images/footer/meta.svg",
  },
  {
    label: "Instagram",
    href: "https://www.instagram.com/graphic_wolves",
    icon: "/images/footer/instagram.svg",
  },
  {
    label: "X",
    href: "https://x.com/graphicwolves",
    icon: "/images/footer/x.svg",
  },
];

/* =========================================================
   HELPERS
========================================================= */

const clamp = (
  value: number,
  min = 0,
  max = 1
) => {
  return Math.min(
    max,
    Math.max(min, value)
  );
};

const mapProgress = (
  progress: number,
  start: number,
  end: number
) => {
  if (start === end) {
    return 0;
  }

  return clamp(
    (progress - start) /
      (end - start)
  );
};

const easeOutCubic = (
  value: number
) => {
  return (
    1 -
    Math.pow(
      1 - value,
      3
    )
  );
};

const easeInOutCubic = (
  value: number
) => {
  return value < 0.5
    ? 4 *
        value *
        value *
        value
    : 1 -
        Math.pow(
          -2 * value + 2,
          3
        ) /
          2;
};

/* =========================================================
   COMPONENT
========================================================= */

export default function FooterSection() {
  const [newsletterLoading, setNewsletterLoading] = useState(false);
  const [newsletterMessage, setNewsletterMessage] = useState("");
  const [newsletterError, setNewsletterError] = useState(false);

  const sectionRef =
    useRef<HTMLElement>(null);

  const leftRef =
    useRef<HTMLSpanElement>(null);

  const rightRef =
    useRef<HTMLSpanElement>(null);

  const meetingLogoRef =
    useRef<HTMLAnchorElement>(null);

  const footerCardRef =
    useRef<HTMLDivElement>(null);

  const swirlPathRef =
    useRef<SVGPathElement>(null);

  useLayoutEffect(() => {
    const section =
      sectionRef.current;

    const left =
      leftRef.current;

    const right =
      rightRef.current;

    const meetingLogo =
      meetingLogoRef.current;

    const footerCard =
      footerCardRef.current;

    const swirlPath =
      swirlPathRef.current;

    if (
      !section ||
      !left ||
      !right ||
      !meetingLogo ||
      !footerCard ||
      !swirlPath
    ) {
      return;
    }

    /* =====================================================
       MOBILE CHECK

       767px se chhoti screens pe scroll animation
       bilkul band kar do — sab elements final
       visible state mein set kar do aur RAF loop
       start hi mat karo.
    ===================================================== */

    const isMobile = window.innerWidth <= 767;

    let rafId: number | null = null;

    /*
      Smoothed progress for premium scroll feel.
    */

    let smoothProgress = 0;

    /* =====================================================
       INITIAL HEADING

       Start:
       call us if you need

       NO overlap.
    ===================================================== */

    gsap.set(left, {
      x: 0,
      opacity: 1,
    });

    gsap.set(right, {
      x: 0,
      opacity: 1,
    });

    /* =====================================================
       INITIAL MEETING LOGO

       Rotate + scale into place.
    ===================================================== */

    gsap.set(
      meetingLogo,
      {
        scale: 0,

        opacity: 0,

        rotation: -300,

        filter:
          "blur(8px)",

        transformOrigin:
          "50% 50%",
      }
    );

    /* =====================================================
       SWIRL DRAW SETUP
    ===================================================== */

    const swirlLength =
      swirlPath.getTotalLength();

    gsap.set(
      swirlPath,
      {
        strokeDasharray:
          swirlLength,

        strokeDashoffset:
          swirlLength,
      }
    );

    /* =====================================================
       FOOTER CARD

       IMPORTANT:
       No scaleX / width animation.

       Whole white card + content fades up together.
    ===================================================== */

    gsap.set(
      footerCard,
      {
        y: 90,

        opacity: 0,

        scale: 0.985,

        filter:
          "blur(7px)",

        transformOrigin:
          "center center",
      }
    );

    /* =====================================================
       SCROLL LOOP
    ===================================================== */

    const render = () => {
      rafId = null;

      const rect = section.getBoundingClientRect();
      const scrollDistance = Math.max(
        section.offsetHeight - window.innerHeight,
        1
      );

      /* =====================================
         RAW PROGRESS
      ===================================== */

      const rawProgress =
        clamp(
          -rect.top /
            scrollDistance
        );

      /* =====================================
         SMOOTH PROGRESS

         Lower = smoother/slower
         Higher = more responsive
      ===================================== */

      smoothProgress +=
        (
          rawProgress -
          smoothProgress
        ) * 0.055;

      const progress =
        smoothProgress;

      /* =====================================
         1 — HEADING OPENS

         Start:
         call us if you need

         End:
         call us   [LOGO]   if you need
      ===================================== */

      const headingProgress =
        easeInOutCubic(
          mapProgress(
            progress,
            0.02,
            0.30
          )
        );

      const splitDistance =
        isMobile ? 42 : 118;

      gsap.set(
        left,
        {
          x:
            -splitDistance *
            headingProgress,
        }
      );

      gsap.set(
        right,
        {
          x:
            splitDistance *
            headingProgress,
        }
      );

      /* =====================================
         2 — MEETING LOGO
         ROTATE + SCALE + FADE
      ===================================== */

      const logoLocal =
        mapProgress(
          progress,
          isMobile ? 0.1 : 0.08,
          isMobile ? 0.26 : 0.34
        );

      const logoProgress =
        easeOutCubic(
          logoLocal
        );

      /*
        Slight scale overshoot.
      */

      let logoScale =
        logoProgress;

      if (
        logoLocal > 0.72 &&
        logoLocal < 1
      ) {
        const overshoot =
          (
            logoLocal -
            0.72
          ) /
          0.28;

        logoScale =
          1 +
          Math.sin(
            overshoot *
              Math.PI
          ) *
            0.055;
      }

      /*
        -300deg -> 0deg
      */

      const logoRotation =
        -300 *
        (
          1 -
          logoProgress
        );

      gsap.set(
        meetingLogo,
        {
          scale:
            logoScale,

          opacity:
            logoProgress,

          rotation:
            logoRotation,

          filter:
            `blur(${
              8 *
              (
                1 -
                logoProgress
              )
            }px)`,
        }
      );

      /* =====================================
         3 — SWIRL DRAW

         Draw under "if you need"
      ===================================== */

      const swirlProgress =
        easeOutCubic(
          mapProgress(
            progress,
            isMobile ? 0.12 : 0.18,
            isMobile ? 0.34 : 0.43
          )
        );

      gsap.set(
        swirlPath,
        {
          strokeDashoffset:
            swirlLength *
            (
              1 -
              swirlProgress
            ),
        }
      );

      /* =====================================
         4 — WHOLE WHITE FOOTER FADE IN UP

         Background + logo + menus +
         captions + input + socials +
         copyright all together.

         NO width animation.
      ===================================== */

      const footerProgress =
        easeOutCubic(
          mapProgress(
            progress,
            isMobile ? 0.2 : 0.37,
            isMobile ? 0.48 : 0.64
          )
        );

      gsap.set(
        footerCard,
        {
          opacity:
            footerProgress,

          y:
            90 *
            (
              1 -
              footerProgress
            ),

          scale:
            0.985 +
            footerProgress *
              0.015,

          filter:
            `blur(${
              7 *
              (
                1 -
                footerProgress
              )
            }px)`,
        }
      );

      /* =====================================
         5 — SMALL FINAL LOGO FLOAT

         Very subtle.
      ===================================== */

      const floatProgress =
        easeOutCubic(
          mapProgress(
            progress,
            0.78,
            1
          )
        );

      /*
        Do not replace rotation here.
        Only Y movement.
      */

      gsap.set(
        meetingLogo,
        {
          y:
            -7 *
            floatProgress,
        }
      );

      if (Math.abs(rawProgress - smoothProgress) > 0.005) {
        scheduleRender();
      }
    };

    const scheduleRender = () => {
      if (rafId === null) {
        rafId = requestAnimationFrame(render);
      }
    };

    window.addEventListener("scroll", scheduleRender, { passive: true });
    window.addEventListener("lenis-scroll", scheduleRender, { passive: true });
    window.addEventListener("resize", scheduleRender);

    /* =====================================================
       START LOOP
    ===================================================== */

    scheduleRender();

    /* =====================================================
       CLEANUP
    ===================================================== */

    return () => {
      window.removeEventListener("scroll", scheduleRender);
      window.removeEventListener("lenis-scroll", scheduleRender);
      window.removeEventListener("resize", scheduleRender);

      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
    };
  }, []);

  /* =========================================================
     NEWSLETTER
  ========================================================= */

  const handleSubmit = (
    event: FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const email = formData.get("email");

    if (typeof email !== "string") {
      return;
    }

    setNewsletterLoading(true);
    setNewsletterMessage("");
    setNewsletterError(false);

    void (async () => {
      try {
        const response = await fetch("/api/newsletter", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        });
        const result = await response.json();

        if (!response.ok) {
          throw new Error(result.message || "Unable to subscribe.");
        }

        setNewsletterMessage(result.message);
        form.reset();
      } catch (error) {
        setNewsletterError(true);
        setNewsletterMessage(
          error instanceof Error
            ? error.message
            : "Unable to subscribe right now. Please try again later."
        );
      } finally {
        setNewsletterLoading(false);
      }
    })();
  };

  return (
    <footer
      ref={sectionRef}
      className={
        styles.footerSection
      }
    >
      {/* =================================================
          STICKY STAGE
      ================================================= */}

      <div
        className={
          styles.stickyStage
        }
      >
        {/* =================================================
            CTA
        ================================================= */}

        <div
          className={
            styles.ctaArea
          }
        >
          <div
            className={
              styles.ctaHeading
            }
          >
            {/* =========================================
                CALL US
            ========================================= */}

            <span
              ref={leftRef}
              className={
                styles.ctaMain
              }
            >
              call us
            </span>

            {/* =========================================
                CENTER MEETING LOGO
            ========================================= */}

            <a
              ref={
                meetingLogoRef
              }
              href="/schedule"
              className={
                styles.meetingLogo
              }
              aria-label="Book a meeting"
            >
              <img
                src="/images/footer/meeting-logo.svg"
                alt="Book a Meeting"
                width={174}
                height={211}
                draggable={false}
                loading="lazy"
                decoding="async"
              />
            </a>

            {/* =========================================
                IF YOU NEED
            ========================================= */}

            <span
              ref={rightRef}
              className={
                styles.ctaItalicWrap
              }
            >
              <span
                className={
                  styles.ctaItalic
                }
              >
                if you need
              </span>

              {/* =====================================
                  SWIRL
              ===================================== */}

              <svg
                className={
                  styles.swirlSvg
                }
                viewBox="0 0 375 17"
                fill="none"
                aria-hidden="true"
              >
                <path
                  ref={
                    swirlPathRef
                  }
                  d="M0.649915 16.9998C31.5624 16.164 62.3362 11.0745 93.0474 7.42132C111.139 5.26442 129.263 3.38776 147.431 2.22173C149.731 2.0716 152.031 1.93481 154.331 1.81136C156.322 1.70127 159.508 1.95149 160.945 1.31092C158.971 2.21672 156.68 2.59205 154.608 3.12252C149.239 4.49373 143.802 5.67977 138.459 7.24615C136.484 7.75526 134.553 8.45347 132.686 9.33301C131.965 9.70334 130.659 10.3639 130.677 11.4649C130.713 13.2314 134.53 13.3565 135.599 13.4666C144.267 14.5176 153.185 13.9671 161.876 13.6418C193.84 12.5208 225.764 10.1387 257.705 8.46723C276.052 7.50138 294.399 6.17522 312.773 7.13607C329.778 8.02185 346.72 10.3089 363.742 10.5991C367.282 10.6592 370.821 10.5991 374.357 10.3839"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
          </div>
        </div>

        {/* =================================================
            WHITE FOOTER CARD

            Entire card fades up as one.
        ================================================= */}

        <div
          ref={
            footerCardRef
          }
          className={
            styles.footerCard
          }
        >
          {/* =============================================
              TOP GRID
          ============================================= */}

          <div
            className={
              styles.footerGrid
            }
          >
            {/* =========================================
                BRAND
            ========================================= */}

            <div
              className={
                styles.brandColumn
              }
            >
              <img
                src="/images/footer/graphic-wolves-logo.svg"
                alt="Graphic Wolves"
                width={402}
                height={54}
                className={
                  styles.footerLogo
                }
                draggable={false}
                loading="lazy"
                decoding="async"
              />

              <p
                className={
                  styles.brandCaption
                }
              >
                we&apos;re a pack of
                brand, web development,
                and e-commerce nerds who
                love building sites and
                stores that actually grow
                the business behind them
              </p>
            </div>

            {/* =========================================
                MENU
            ========================================= */}

            <nav
              className={
                styles.menuColumn
              }
              aria-label="Footer navigation"
            >
              {menuItems.map(
                (item) => (
                  <Link
                    key={
                      item.label
                    }
                    href={
                      item.href
                    }
                    className={
                      styles.menuLink
                    }
                  >
                    {
                      item.label
                    }
                  </Link>
                )
              )}
            </nav>

            {/* =========================================
                NEWSLETTER
            ========================================= */}

            <div
              className={
                styles.newsletterColumn
              }
            >
              <p
                className={
                  styles.newsletterCaption
                }
              >
                keep in touch — every
                so often we drop insights,
                fresh work, and the
                occasional bad pun.
                no spam, promise.
              </p>

              <form
                className={
                  styles.newsletterForm
                }
                onSubmit={
                  handleSubmit
                }
              >
                <input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  aria-label="Email Address"
                  autoComplete="email"
                  required
                  disabled={newsletterLoading}
                />

                <button
                  type="submit"
                  disabled={newsletterLoading}
                >
                  <span>
                    {newsletterLoading ? "Joining..." : "Join"}
                  </span>

                  <span
                    className={
                      styles.joinArrow
                    }
                  >
                    →
                  </span>
                </button>
              </form>

              {newsletterMessage && (
                <p
                  className={styles.newsletterStatus}
                  role={newsletterError ? "alert" : "status"}
                  aria-live="polite"
                >
                  {newsletterMessage}
                </p>
              )}
            </div>
          </div>

          {/* =============================================
              BOTTOM
          ============================================= */}

          <div
            className={
              styles.bottomArea
            }
          >
            <div
              className={
                styles.bottomDivider
              }
            />

            <div
              className={
                styles.bottomRow
              }
            >
              <div
                className={
                  styles.bottomLeft
                }
              >
                {/* =====================================
                    SOCIALS
                ===================================== */}

                <div
                  className={
                    styles.socials
                  }
                >
                  {socials.map(
                    (
                      social
                    ) => (
                      <a
                        key={
                          social.label
                        }
                        href={
                          social.href
                        }
                        target="_blank"
                        rel="noopener noreferrer"
                        className={
                          styles.socialLink
                        }
                        aria-label={
                          social.label
                        }
                      >
                        <img
                          src={
                            social.icon
                          }
                          alt=""
                          width={42}
                          height={41}
                          draggable={false}
                          loading="lazy"
                          decoding="async"
                        />
                      </a>
                    )
                  )}
                </div>

                {/* =====================================
                    COPYRIGHT
                ===================================== */}

                <p
                  className={
                    styles.copyright
                  }
                >
                  Graphicwolves™ 2026,
                  All Rights Reserved
                </p>
              </div>

              {/* =====================================
                  LEGAL LINKS
              ===================================== */}

              <div
                className={
                  styles.bottomLinks
                }
              >
                <Link
                  href="/privacy-policy"
                  className={
                    styles.bottomLink
                  }
                >
                  Privacy Policy
                </Link>

                <span
                  className={
                    styles.bottomLinkDivider
                  }
                  aria-hidden="true"
                >
                  |
                </span>

                <Link
                  href="/terms-conditions"
                  className={
                    styles.bottomLink
                  }
                >
                  Terms &amp; Conditions
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}