import Link from 'next/link';
import Image from 'next/image';
import type { WordPressPost } from '@/lib/wordpress/types';
import {
  getFeaturedImage,
  getPostCategories,
  estimateReadTime,
  formatDate,
  ensureHeadingIds,
} from '@/lib/wordpress/types';
import TableOfContents from '@/components/blog/TableOfContents/TableOfContents';
import styles from './PostContent.module.css';

interface PostContentProps {
  post: WordPressPost;
}

export default function PostContent({ post }: PostContentProps) {
  const image = getFeaturedImage(post);
  const categories = getPostCategories(post);
  const readTime = estimateReadTime(post.content.rendered);

  const excerptText = post.excerpt.rendered.replace(/<[^>]*>/g, '').trim();

  const contentHtml = ensureHeadingIds(post.content.rendered);

  return (
    <article className={styles.article}>
      {/* BACK BUTTON */}
      <div className={styles.backWrap}>
        <Link href="/blog" className={styles.back}>
          <span aria-hidden="true">←</span> Back
        </Link>
      </div>

      {/* HEADER */}
      <header className={styles.header}>
        {categories.length > 0 && (
          <div className={styles.categoryTags}>
            {categories.map((category) => (
              <Link
                key={category.id}
                href={`/blog/category/${category.slug}`}
                className={styles.categoryTag}
              >
                {category.name}
              </Link>
            ))}
          </div>
        )}
        <h1
          className={styles.title}
          dangerouslySetInnerHTML={{ __html: post.title.rendered }}
        />
        {excerptText && <p className={styles.excerpt}>{excerptText}</p>}
        <div className={styles.meta}>
          <time dateTime={post.date} className={styles.date}>
            {formatDate(post.date)}
          </time>
          <span className={styles.readTimeBadge}>{readTime} min Read</span>
        </div>
      </header>

      {/* CONTENT + SIDEBAR */}
      <div className={styles.layout}>
        {/* MAIN CONTENT */}
        <div className={styles.contentWrap}>
          {image && (
            <div className={styles.featuredImageWrap}>
              <Image
                src={image.source_url}
                alt={image.alt_text || post.title.rendered}
                fill
                className={styles.featuredImage}
                sizes="(max-width: 768px) 100vw, 65vw"
                priority
              />
            </div>
          )}
          <div
            className={styles.content}
            dangerouslySetInnerHTML={{ __html: contentHtml }}
          />

          {/* ABOUT CTA BOX */}
          <div className={styles.aboutBox}>
            <div className={styles.aboutLogoWrap}>
              <img
                src="/images/blog/cta-logo.svg"
                alt="Graphic Wolves logo"
                className={styles.aboutLogo}
              />
            </div>
            <h3 className={styles.aboutTitle}>About Graphic Wolves</h3>
            <p className={styles.aboutDesc}>
              we&apos;re a pack of brand, web develop, and e-commerce nerds who love building
              sites and stores that actually grow the business behind them
            </p>
            <hr className={styles.aboutDivider} />
            <Link href="/services" className={styles.aboutBtn}>
              View Our Services
            </Link>
          </div>
        </div>

        {/* SIDEBAR */}
        <aside className={styles.sidebar} aria-label="Article navigation">
          <div className={styles.sidebarSticky}>
            <TableOfContents content={contentHtml} />

            {/* SHARE */}
            <div className={styles.shareBox}>
              <p className={styles.shareLabel}>Share</p>
              <div className={styles.shareLinks}>
                <a
                  href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(post.link)}&text=${encodeURIComponent(post.title.rendered)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Share on X (Twitter)"
                  className={styles.shareLink}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </a>
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(post.link)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Share on Facebook"
                  className={styles.shareLink}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </a>
                <a
                  href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(post.link)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Share on LinkedIn"
                  className={styles.shareLink}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                  </svg>
                </a>
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(post.title.rendered + ' ' + post.link)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Share on WhatsApp"
                  className={styles.shareLink}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </article>
  );
}
